{-
    File: Main.hs
    Project: VUT-FIT FLP Functional project (knapsack-problem)
    Author: Adam Švenk (xsvenk00)
    Version: 1.0
    Date: 24.02.2023
-}

{- 
    Import modules
-}
module Main (main) where
import GHC.Base ()
import System.Environment (getArgs)
import System.IO (IOMode(ReadMode), openFile, hGetContents, hClose)
import GHC.IO.Handle.FD (stdin)
import GHC.IO.Handle.Types (Handle)
import Text.Parsec()
import Text.ParserCombinators.Parsec
import Control.Monad.RWS.Strict()

data Item = Item {weight :: Int, cost :: Int} deriving (Show)
data Knapsack = Knapsack {maxWeight :: Int, minCost :: Int, items :: [Item]}
data Solution = Solution {included :: [Bool]}

instance Show Solution where
  show :: Solution -> String
  show (Solution included) = "Solution [" ++ init (concatMap (\x -> if x then "1 " else "0 ") included) ++ "]"

instance Show Knapsack where
  show :: Knapsack -> String
  show (Knapsack maxWeight minCost items) =
    "Knapsack {\n"
    ++ "maxWeight: " ++ show maxWeight ++ "\n"
    ++ "minCost: " ++ show minCost ++ "\n"
    ++ "items: [\n"
    ++ concatMap (("    " ++) . showItem) items
    ++ "]\n"
    ++ "}"
    where
      showItem item = "Item {\n"
                      ++ "    weight: " ++ show (weight item) ++ "\n"
                      ++ "    cost: " ++ show (cost item) ++ "\n"
                      ++ "    }\n"

parseArgs :: [String] -> IO GHC.IO.Handle.Types.Handle
parseArgs["-i"] = return GHC.IO.Handle.FD.stdin
parseArgs["-b"] = return GHC.IO.Handle.FD.stdin
parseArgs["-o"] = return GHC.IO.Handle.FD.stdin
parseArgs["-i", fileName] = openFile fileName ReadMode
parseArgs["-b", fileName] = openFile fileName ReadMode
parseArgs["-o", fileName] = openFile fileName ReadMode
parseArgs _ = error "Error: Invalid program arguments."

boolCombinations :: Int -> [Solution]
boolCombinations 0 = [Solution []]
boolCombinations n = [Solution (x:xs) | x <- [False, True], Solution xs <- boolCombinations (n-1)]

booleanCombinations :: Int -> ([Bool] -> a -> Bool) -> a -> [[Bool]]
booleanCombinations 0 f p = if f [] p then [[]] else []
booleanCombinations n f p = [x:xs | x <- [True,False], xs <- booleanCombinations (n-1) (\ys p' -> f (x:ys) p') p, f (x:xs) p]

--buildItems :: Knapsack -> Solution -> [Item]
--buildItems Knapsack{items = xs} Solution{included = bs} = [x | (x, b) <- zip xs bs, b]

buildItems2 :: Knapsack -> [Bool] -> [Item]
buildItems2 Knapsack{items = xs} bs = [x | (x, b) <- zip xs bs, b]

buildItems :: Knapsack -> Solution -> [Item]
buildItems Knapsack{items = xs} Solution{included = bs} = [x | (x, b) <- zip xs bs, b]

itemsWeight :: [Item] -> Int
itemsWeight items = sum $ map weight items

itemsCost :: [Item] -> Int
itemsCost items = sum $ map cost items

validateSolution :: Knapsack -> Solution -> Bool
validateSolution knapsack solution = itemsWeight (buildItems knapsack solution) <= maxWeight knapsack && itemsCost (buildItems knapsack solution) >= minCost knapsack

getAllSolutions :: Knapsack -> [Solution]
getAllSolutions knapsack = filter (validateSolution knapsack) (boolCombinations (length (items knapsack)))

bestSolution :: Knapsack -> [Solution] -> String
bestSolution _ [] = "False"
bestSolution knapsack solutions = show $ head $ filter (\x -> itemsCost (buildItems knapsack x) == maximum (map (itemsCost . buildItems knapsack) solutions)) solutions

validateSolution2 :: [Bool] -> Knapsack -> Bool
validateSolution2 solution knapsack = itemsWeight (buildItems2 knapsack solution) <= maxWeight knapsack && itemsCost (buildItems2 knapsack solution) >= minCost knapsack

solveKnapsack :: Knapsack -> String -> String
solveKnapsack knapsack solverType
  | solverType == "-i" = show knapsack
  | solverType == "-b" = bestSolution knapsack (getAllSolutions knapsack)
--  | solverType == "-b" = show $ booleanCombinations (length (items knapsack)) validateSolution2 knapsack
  | solverType == "-o" = "Solved by genetic algo"
  | otherwise = error "Error: Invalid solver type."

parseKnapSack :: Parser Knapsack
parseKnapSack = do
  _ <- string "Knapsack {"
  spaces
  maxWeight <- parseMaxWeight
  spaces
  minCost <- parseMinCost
  spaces
  items <- parseItemList
  spaces
  _ <- char '}'
  spaces
  return $ Knapsack maxWeight minCost items

parseMinCost :: Parser Int
parseMinCost = do
  _ <- string "minCost:"
  spaces
  c <- many1 digit
  return $ read c

parseMaxWeight :: Parser Int
parseMaxWeight = do
  _ <- string "maxWeight:"
  spaces
  w <- many1 digit
  return $ read w

parseItemList :: Parser [Item]
parseItemList = do
  _ <- string "items: ["
  spaces
  items <- many1 parseItem
  _ <- string "]"
  return items

parseItem :: Parser Item
parseItem = do
  _ <- string "Item {"
  spaces
  w <- parseWeight
  spaces
  c <- parseCost
  spaces
  _ <- char '}'
  spaces
  return $ Item w c

parseWeight :: Parser Int
parseWeight = do
  _ <- string "weight:"
  spaces
  w <- many1 digit
  return $ read w

parseCost :: Parser Int
parseCost = do
  _ <- string "cost:"
  spaces
  c <- many1 digit
  return $ read c

main :: IO ()
main = do
    args <- getArgs
    
    handle <- parseArgs args
    contents <- hGetContents handle

    case parse parseKnapSack "" contents of
      Left err -> putStrLn $ "Error: " ++ show err
      Right knapsack -> putStrLn $ solveKnapsack knapsack (head args)

    hClose handle